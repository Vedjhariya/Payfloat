
const handleContact = async (req, res) => {
  try {
    console.log("Message Received:", req.body);
    res.status(200).json("Message received");
  } catch (err) {
    res.status(500).json("Error");
  }
};

module.exports = { handleContact };
